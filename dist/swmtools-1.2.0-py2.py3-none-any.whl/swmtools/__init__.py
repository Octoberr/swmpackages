from swmtools import manytools
