from swmtools import manytools, readmanyfiles, timeformat
from swmtools.logger import MyLogger
